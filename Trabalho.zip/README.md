## Para Compilar:
> mkdir bin
> javac -d bin src/utilidades/*.java src/server/*.java src/gui/*.java
## Para executar o Server:
> java -classpath bin server.TCPServer
## Para executar o Cliente:
> java -classpath bin gui.GUICliente

## Diretório do Servidor:
> GUI Client/src/server/DiretorioServidor

## Diretório de Downloads do Cliente
> GUI Client/src/gui/Downloads